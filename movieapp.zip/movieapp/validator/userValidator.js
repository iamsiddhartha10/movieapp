const Joi = require('@hapi/joi');
const Joy = require('@hapi/joi');

const schema = Joy.object({
    username : Joi.string().alphanum().required().min(3).max(10),
    email : Joi.string().email().required(),
    password : Joi.string().pattern(new RegExp('^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$')).message("Your password must contain:\nAt least one upper case,\nAt least one lower case,\nAt least one digit,\nAt least one special character,\nand Minimum eight in length.").required(),
    first_name : Joi.string().required(),
    last_name : Joi.string().required()
});

module.exports = schema;