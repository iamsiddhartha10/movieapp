module.exports={
    userValidator:require('./userValidator')
}