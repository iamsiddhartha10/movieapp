const morgan = require('morgan');
const {logger} = require('../configurations');
const { stream } = require('../configurations/logger');
const express= require('express');

module.exports = (app)=>{
    app.use(morgan('combined', {stream:logger.stream}));
    app.use(express.json());
}