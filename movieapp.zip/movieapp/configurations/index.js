
module.exports = {
     logger : require('./logger'),
     dbCon : require('./db')
    }