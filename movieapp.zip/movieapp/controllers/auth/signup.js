const postSignup = (req,res,next)=>{
   console.log(req.body);
};

module.exports = {postSignup};