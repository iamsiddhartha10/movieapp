const logger = require('../../configurations/logger');

module.exports.getLogin = (req,res,next)=>{
    logger.info('Hello'); //i.e info level
    res.send("Welcome to the login page");
}